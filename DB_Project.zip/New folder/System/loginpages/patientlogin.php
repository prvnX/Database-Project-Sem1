<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>PharmaLink patientlogin </title>
    <link rel="stylesheet" href="../css/loginstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>

    <div class="content">
        <div class="img">
            <img src="../images/logo.png" height="25px">
        </div>
        <form action="patientlogin.php" method="POST">
            <h1>Patient Login</h1>
            <div class="input-box">
                <i class='bx bxs-user'></i>    
                <input type="text" placeholder="username" name="username" required>
            </div>
            <div class="input-box">
                <i class='bx bxs-lock'></i>
                <input type="password" placeholder="password" name="password" required>
            </div>
            <button type="submit" class="btn" name="submit"><span></span>Login</button>
            <br>
            <a href="../index.php"><br><button type="button" class="btn" name="submit">Back</button></a>
        </form>
    </div>
    
<?php
if(isset($_POST['submit']))
{
$user=$_POST['username'];
$pw=$_POST['password'];
$server="localhost";
$db="pharma2";
$conn=new mysqli($server,$user,$pw,$db);
if($conn->connect_error){
    header('Location:invalidlogin.php');
    exit;
}
session_start();
$_SESSION['patientpassword']=$pw;
$_SESSION['patientuname']=$user;
header('location:getpatientid.php?uname='.urlencode($user));  
$conn->close();
}
?>
</body>
</html>
