<?php
session_start();
$id=$_SESSION['staffid'];
$conid=$_GET['conid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Update consult</title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="updatepatientreport.php?conid=<?php echo $conid;?>" method="POST">
            <h1>Update consult</h1>
            <h5>Please Fill the New Details</h5>
            <div class="input-box">
            <i class='bx bxs-droplet' ></i>
                 <input type="text" placeholder="Blood Pressure" name="bp" required>
            </div>
            <div class="input-box">
            <i class='bx bxs-heart' ></i> 
                <input type="text" placeholder="Pulse" name="pulse" required>
            </div>
            <div class="input-box">
            <i class='bx bx-plus-medical'></i>
                <input type="text" placeholder="Temperature" name="temp" required>
            </div>
            <div class="input-box">
            <i class='bx bxs-virus'></i>   
                <input type="text" placeholder="Symptoms" name="symptoms" required>
            </div> 
            <center> Date Taken </center>
            <div class="input-box">
                <input type="datetime-local" placeholder="date" name="date" required>
            </div>
            <button type="submit" class="btn" name="submit"><span></span>Update</button>
            <br><br>
            <a href="../../roles/chief.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
        </div>
        

    
    </div>
<?php
if(isset($_POST['submit'])){
    @include 'staffconfig.php';
    $conid=$_GET['conid'];
    $bp=$_POST['bp'];
    $pulse=$_POST['pulse'];
    $temp=$_POST['temp'];
    $symptom=$_POST['symptoms'];
    $date=$_POST['date'];

    $sql1="UPDATE consult SET blood_pressure='$bp',pulse='$pulse',temperature='$temp',consulted_at='$date',staff_id='$id' WHERE id=$conid;";
    $sql2="UPDATE symptom SET description='$symptom' WHERE consult_id=$conid;";
    if($conn->query($sql1)==TRUE && $conn->query($sql2)==TRUE  ){
        header('location:updatedsuccessconsult.php');
    }
    else{
        echo "ERROR <h5>".$conn->error."</h5>";
    }
}
?>

