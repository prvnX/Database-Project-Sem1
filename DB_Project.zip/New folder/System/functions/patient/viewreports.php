<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Patient view Reports </title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href='../../css/patientfunctions/viewreportsstyle.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
            <h1>Patient Reports</h1>
            <div class="data">
            <?php
               if(!(isset($_SESSION['patientuname'])&& isset($_SESSION['patientpassword']) && isset($_SESSION['patientid']))){
                   echo "<h1>SESSION _ERROR</h1>";
                    exit;
               }
            $user=$_SESSION['patientuname'];
            $pw=$_SESSION['patientpassword'];
            $server="localhost";
            $db="pharma2";
            $id=$_SESSION['patientid'];          
            $conn=new mysqli($server,$user,$pw,$db);
            $sql="SELECT blood_pressure,pulse,temperature,sy.description,s.name,consulted_at FROM consult c
                   INNER JOIN staff s ON c.staff_id=s.id INNER JOIN symptom sy ON c.id=sy.consult_id WHERE patient_id=$id;";
            $result=$conn->query($sql);
            if($result->num_rows>0){
                echo "<table border='1px'><tr><th>BP</th><th>Pulse</th><th>Temperature</th><th>Symptoms</th><th>Consulted by</th><th>Consulted at</th></tr>";
                while($row=$result->fetch_assoc()){
                    echo "<tr><td>".$row['blood_pressure']."</td><td>".$row['pulse']."</td><td>".$row['temperature'].
                    "</td><td>".$row['description']."</td><td>".$row['name']."</td><td>".$row['consulted_at']."</td></tr>";
                }
                echo"</table>";
             }
        else{
                echo "No Results";
            }
            $conn->close();
            ?>
            </div>
            <a href="../../loginpages/getpatientid"><br><button type="button" class="btn" name="submit">Back</button></a>
        </form>
    </div>
 
</body>
</html>