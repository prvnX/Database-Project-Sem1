<?php

session_start();
$id=$_SESSION['staffid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Add a new Patient </title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="addpatient.php" method="POST">
            <h1>Add a new Patient </h1>
            <h5>Please Fill the following Details</h5>
            <div class="input-box">
            <i class='bx bx-user'></i>  
                <input type="number" placeholder="Patient id" name="patientid" required>
            </div>
            <div class="input-box">
            <i class='bx bx-rename'></i> 
                <input type="text" placeholder="Full Name" name="name" required>
            </div>
            <div class="input-box">
            <i class='bx bxs-envelope'></i>   
                <input type="text" placeholder="Address" name="address" required>
            </div>
            <div class="input-box">
            <i class='bx bxs-phone'></i>   
                <input type="text" placeholder="Contact No" name="tpno" required>
            </div>
            <center>Date of Birth</center>
            <div class="input-box">
                <input type="datetime-local" placeholder="dob" name="dob" required>
            </div>
            
            <button type="submit" class="btn" name="submit"><span></span>Submit</button>
            <br><br>
            <a href="../../roles/pharmacist.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
        

    
    </div>
<?php
if(isset($_POST['submit'])){
    @include 'staffconfig.php';
    $pid=$_POST['patientid'];
    $name=$_POST['name'];
    $address=$_POST['address'];
    $tpno=$_POST['tpno'];
    $dob=$_POST['dob'];

    $sql="INSERT INTO patient VALUES ($pid,'$name','$dob','$tpno','$address');";
    if($conn->query($sql)==TRUE){
        header('location:addedsuccesspatient.php');
    }
    else{
        echo "ERROR <h5>".$conn->error."</h5>";
    }
}
?>