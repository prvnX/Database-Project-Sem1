<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Patient view profile </title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href='../../css/patientfunctions/viewprofilestyle.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
            <h1>Patient Profile</h1>
            <div class="data">
            <?php
               if(!(isset($_SESSION['patientuname'])&& isset($_SESSION['patientpassword']) && isset($_SESSION['patientid']))){
                   echo "<h1>SESSION _ERROR</h1>";
                    exit;
               }
            $user=$_SESSION['patientuname'];
            $pw=$_SESSION['patientpassword'];
            $server="localhost";
            $db="pharma2";
            $id=$_SESSION['patientid'];          
            $conn=new mysqli($server,$user,$pw,$db);
            $sql="SELECT * FROM patient WHERE id=$id;";
            $result=$conn->query($sql);

            if($result->num_rows>0){
                $row=$result->fetch_assoc();
                    echo "<table><tr><td> ID :</td><td> ".$row['id']."</td></tr><tr><td> Name : </td><td>".$row['name']."</td></tr><tr><td>
                    DOB</td><td>".$row['date_of_birth']."</td></tr><tr><td>Contact NO : </td><td>".$row['contact_no']."</td></tr><tr><td>
                    address : </td><td>".$row['address']."</td></tr></table>";
            }
        else{
                echo "No Results";
            }
            $_SESSION['patientid']=$id;
            $conn->close();
            ?>
            </div>
            
            
            <a href="../../loginpages/getpatientid"><br><button type="button" class="btn" name="submit">Back</button></a>
        </form>
    </div>
 
</body>
</html>