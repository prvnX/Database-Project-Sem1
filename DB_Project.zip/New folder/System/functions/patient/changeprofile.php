<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Patient change profile </title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href='../../css/patientfunctions/changeprofilestyle.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
            <h1>Change Profile</h1>
            <div class="data">
            <?php
               if(!(isset($_SESSION['patientuname'])&& isset($_SESSION['patientpassword']) && isset($_SESSION['patientid']))){
                   echo "<h1>SESSION _ERROR</h1>";
                    exit;
               }
            $user=$_SESSION['patientuname'];
            $pw=$_SESSION['patientpassword'];
            $server="localhost";
            $db="pharma2";
            $id=$_SESSION['patientid'];          
            $conn=new mysqli($server,$user,$pw,$db);
            $sql="SELECT * FROM patient WHERE id=$id;";
            $result=$conn->query($sql);

            if($result->num_rows>0){
                $row=$result->fetch_assoc();
                    echo "<table><tr><td> Name :</td><td>".$row['name']."</td><td><a href='update/updatename.php'><i class='bx bxs-edit'></i></a></td></tr><tr><td>
                    DOB</td><td>".$row['date_of_birth']."</td><td><a href='update/updatedob.php'><i class='bx bxs-edit'></i></a></td></tr><tr><td>Contact NO : </td><td>".$row['contact_no']."</td><td><a href='update/updatecontact.php'><i class='bx bxs-edit'></i></a></td></tr><tr><td>
                    address : </td><td>".$row['address']."</td><td><a href='update/updateaddress.php'><i class='bx bxs-edit'></i></a></td></tr></table>";
            }
        else{
                echo "No Results";
            }
            $_SESSION['patientid']=$id;
            $conn->close();
            ?>
            </div>
            
            <a href="../../loginpages/getpatientid"><br><button type="button" class="btn" name="submit">Back</button></a>
        </form>
    </div>
 
</body>
</html>