<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>PharmaLink CEO Menu </title>
    <link rel="stylesheet" href="../css/ceopagestyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    
    <section>
        <div class="box">
            <div class="img">
                <img src="../images/logo.png">
            </div>
            <h1>Welocme
                <?php
                $id=$_GET['id'];
                $_SESSION['staffid']=$id;
                if((isset($_SESSION['staffpassword'])) && (isset($_SESSION['stafftuname']))){
                    $pword=$_SESSION['staffpassword'];
                    $uname=$_SESSION['stafftuname'];
                    $server='localhost';
                    $db='pharma2';
                    $conn=new mysqli($server,$uname,$pword,$db);
                    if($conn->connect_error){
                        echo "Connection Failed";
                        exit;
                    }
                        $sql="SELECT s.name FROM staff s WHERE id=$id;";
                        $result=$conn->query($sql);
                        if($result->num_rows>0){
                             $row=$result->fetch_assoc();
                             $name=$row['name'];   
                            echo $name;
                    }
                    }
 
            ?>
            </h1>
            <a href="../functions/ceo/viewprofile.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/viewacount.jpg" height="50px">
                </div>
                <div class="content">
                    <h3>View Profile</h3>
                
                <p>View Your Profile and Details.</p>
            </div>
            </div>
            </a>

            <a href="../functions/ceo/viewstaff.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/viewstaff.png" height="50px">
                </div>
                <div class="content">
                    <h3>View Staff </h3>
                <p>View Your All staff,Working staff and Retired Staff</p>
            </div>
            </div>
            </a>

            <a href="../functions/ceo/addstaff.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/addstaff.png" height="50px">
                </div>
                <div class="content">
                    <h3>Add a Staff Member</h3>
                
                <p>Add a new staff member.</p>
            </div>
            </div>
            </a>
            <a href="../functions/ceo/removestaff.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/removestaff.png" height="50px">
                </div>
                <div class="content">
                    <h3>Remove a staff member</h3>
                <p>Remove a staff member.</p>
                </div>
            </div>
            </a>
            <a href="../functions/ceo/viewsales.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/viewsales.png" height="50px">
                </div>
                <div class="content">
                    <h3>View Sales</h3>
                <p>View sales between two days or View all sales.</p>
                </div>
            </div>
            </a>

            <a href="../functions/ceo/changeprofile.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/changeaccount.png" height="50px">
                </div>
                <div class="content">
                    <h3>Change your Profile</h3>
               
                <p>Change your Name and Your pesonal Details.</p>
             </div>
            </div>
            </a>
            <a href="../index.php"><br><button type="button" class="btn" name="submit"><div class="buttxt">Log out</div></button></a>
        </div>
        
    </section>
    
</body>
</div>
</body>
</html>