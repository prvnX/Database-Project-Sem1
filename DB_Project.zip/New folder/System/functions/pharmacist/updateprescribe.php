<?php
session_start();
$id=$_SESSION['staffid'];
$conid=$_GET['conid'];
$preid=$_GET['preid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Update Prescription</title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="updateprescribe.php?conid=<?php echo $conid;?>&preid=<?php echo $preid;?>" method="POST">
            <h1>Update Prescription</h1>
            <h5>Please Fill the New Details</h5> 
            <div class="input-box">
                <div class="select-box">
                <select name="product" >
                    <option value="" disabled selected>Select the Medication</option>
                    <?php
                    
                     @include 'staffconfig.php';
                     $sql="SELECT id,name FROM product;";
                     $result=$conn->query($sql);
                     while($row=$result->fetch_assoc()){
                        $id=$row['id'];
                        $name=$row['name'];
                        echo "<option value='$id'>".$name."</option>";
                     }

                     ?>
                     </select>
                </select>
                </div>
            </div>

            <div class="input-box">
            <i class='bx bx-package'></i>   
                <input type="text" placeholder="Quantity" name="qty" required>
            </div>
            
            <center> Date </center>
            <div class="input-box">
                <input type="datetime-local" placeholder="date" name="date" required>
            </div>

            <button type="submit" class="btn" name="submit"><span></span>Update</button>
            <br><br>
            <a href="../../roles/pharmacist.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
        </div>
        

    
    </div>
<?php
if(isset($_POST['submit'])){
    $preid=$_GET['preid'];
    $conid=$_GET['conid'];
    $product=$_POST['product'];
    $qty=$_POST['qty'];
    $date=$_POST['date'];
    $staffid=$_SESSION['staffid'];
    $sql="UPDATE prescribe SET product_id=$product,quantity='$qty',prescribed_at='$date',staff_id='$staffid' WHERE consult_id=$conid AND id=$preid;";
    if($conn->query($sql)==TRUE ){
        header('location:updatedsuccessconsult.php');
    }
    else{
        echo "ERROR <h5>".$conn->error."</h5>";
    }
}
?>

