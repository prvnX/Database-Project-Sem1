<?php

session_start();
$id=$_SESSION['patientid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Add a order</title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="addorder.php" method="POST">
            <h1>Add a new order </h1>
            <h5>Please Fill the following Details</h5>
            
                <div class="select-box">
                <select name="prescribeid" >
                    <option value="" disabled selected>Select the PrescribeID</option>
                    <?php
                     @include 'patientconfig.php';
                     $sql="SELECT p.id FROM prescribe p INNER JOIN consult c ON p.consult_id=c.id WHERE c.patient_id=$id;";
                     $result=$conn->query($sql);
                     while($row=$result->fetch_assoc()){
                        $id=$row['id'];
                        echo "<option value='$id'>".$id."</option>";
                     }

                     ?>
                     </select>
                    </div>
                    


            <div class="input-box">
                <div class="select-box">
                <select name="product" >
                    <option value="" disabled selected>Select the Medication</option>
                    <?php
                     @include 'patientconfig.php';
                     $sql="SELECT id,name FROM product;";
                     $result=$conn->query($sql);
                     while($row=$result->fetch_assoc()){
                        $id=$row['id'];
                        $name=$row['name'];
                        echo "<option value='$id'>".$name."</option>";
                     }

                     ?>
                     </select>
                </div>
            </div>
            

            <div class="input-box">
            <i class='bx bx-package'></i>   
                <input type="text" placeholder="Quantity" name="qty" required>
            </div>

            <div class="input-box">
            <i class='bx bx-package'></i>   
                <input type="text" placeholder="Enter Your Cost" name="cost" required>
            </div>

            
            <center>Purchased Date </center>
            <div class="input-box">
                <input type="datetime-local" placeholder="date" name="date" required>
            </div>

            <button type="submit" class="btn" name="submit"><span></span>Add Order </button>
            <br><br>
            <a href="../../loginpages/getpatientid.php">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
        </div>
        

    
    </div>
<?php
if(isset($_POST['submit'])){
    $preid=$_POST['prescribeid'];
    $productid=$_POST['product'];
    $qty=$_POST['qty'];
    $date=$_POST['date'];
    $cost=$_POST['cost'];

    $sql="INSERT INTO purchase(purchased_at,product_id,prescribe_id,quantity,cost) VALUES ('$date',$productid,$preid,'$qty','$cost');";
    if($conn->query($sql)==TRUE){
        header('location:success.php');
    }
    else{
        echo "ERROR <h5>".$conn->error."</h5>";
    }
}
?>

