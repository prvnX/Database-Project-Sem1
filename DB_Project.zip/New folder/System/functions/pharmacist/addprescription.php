<?php

session_start();
$id=$_SESSION['staffid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Add a new prescription</title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="addprescription.php" method="POST">
            <h1>Add a new Prescription </h1>
            <h5>Please Fill the following Details</h5>
            <div class="input-box">
            <i class='bx bx-band-aid'></i>  
                <input type="number" placeholder="Prescribe id" name="prescribeid" required>
            </div>
            <div class="input-box">
            <i class='bx bx-user'></i>  
                <input type="number" placeholder="Consult id" name="consultid" required>
            </div>
            
            <div class="input-box">
                <div class="select-box">
                <select name="product" >
                    <option value="" disabled selected>Select the Medication</option>
                    <?php
                     @include 'staffconfig.php';
                     $sql="SELECT id,name FROM product;";
                     $result=$conn->query($sql);
                     while($row=$result->fetch_assoc()){
                        $id=$row['id'];
                        $name=$row['name'];
                        echo "<option value='$id'>".$name."</option>";
                     }

                     ?>
                     </select>
                </select>
                </div>
            </div>

            <div class="input-box">
            <i class='bx bx-package'></i>   
                <input type="text" placeholder="Quantity" name="qty" required>
            </div>
            
            <center> Date </center>
            <div class="input-box">
                <input type="datetime-local" placeholder="date" name="date" required>
            </div>

            <button type="submit" class="btn" name="submit"><span></span>Add Prescription </button>
            <br><br>
            <a href="../../roles/pharmacist.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
        </div>
        

    
    </div>
<?php
if(isset($_POST['submit'])){
    $preid=$_POST['prescribeid'];
    $conid=$_POST['consultid'];
    $productid=$_POST['product'];
    $qty=$_POST['qty'];
    $date=$_POST['date'];

    $sql="INSERT INTO prescribe VALUES ($preid,$conid,$productid,'$date',$id,'$qty');";
    if($conn->query($sql)==TRUE){
        header('location:success.php');
    }
    else{
        echo "ERROR <h5>".$conn->error."</h5>";
    }
}
?>

