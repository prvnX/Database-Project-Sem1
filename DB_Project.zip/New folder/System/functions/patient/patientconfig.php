<?php
$user=$_SESSION['patientuname'];
$pw=$_SESSION['patientpassword'];
$server="localhost";
$db="pharma2";          
$conn=new mysqli($server,$user,$pw,$db);
if($conn->connect_error){
        echo "Error";
        exit;
}
?>