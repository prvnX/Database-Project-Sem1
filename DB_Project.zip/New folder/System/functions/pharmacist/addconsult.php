<?php

session_start();
$id=$_SESSION['staffid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Add a new consult</title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="addconsult.php" method="POST">
            <h1>Add a new consult </h1>
            <h5>Please Fill the following Details</h5>
            <div class="input-box">
            <i class='bx bx-band-aid'></i>  
                <input type="number" placeholder="consult_id" name="consultid" required>
            </div>
            <div class="input-box">
            <i class='bx bx-user'></i>  
                <input type="number" placeholder="patient_id" name="patientid" required>
            </div>
            <div class="input-box">
            <i class='bx bxs-droplet' ></i>
                 <input type="text" placeholder="Blood Pressure" name="bp" required>
            </div>
            <div class="input-box">
            <i class='bx bxs-heart' ></i> 
                <input type="text" placeholder="Pulse" name="pulse" required>
            </div>
            <div class="input-box">
            <i class='bx bx-plus-medical'></i>
                            <input type="text" placeholder="Temperature" name="temp" required>
            </div>

            <div class="input-box">
            <i class='bx bxs-virus'></i>   
                <input type="text" placeholder="Symptoms" name="symptoms" required>
            </div>
            
            <center> Date Taken </center>
            <div class="input-box">
                <input type="datetime-local" placeholder="date" name="date" required>
            </div>
            <button type="submit" class="btn" name="submit"><span></span>Submit</button>
            <br><br>
            <a href="../../roles/pharmacist.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
        </div>
        

    
    </div>
<?php
if(isset($_POST['submit'])){
    @include 'staffconfig.php';
    $conid=$_POST['consultid'];
    $pid=$_POST['patientid'];
    $bp=$_POST['bp'];
    $pulse=$_POST['pulse'];
    $temp=$_POST['temp'];
    $symptom=$_POST['symptoms'];
    $date=$_POST['date'];

    $sql1="INSERT INTO consult VALUES ($conid,$pid,$id,'$bp','$pulse','$temp','$date');";
    $sql2="INSERT INTO symptom (consult_id,description) VALUES ($conid,'$symptom');";
    if($conn->query($sql1)==TRUE && $conn->query($sql2)==TRUE  ){
        header('location:addedsuccessconsult.php');
    }
    else{
        echo "ERROR <h5>".$conn->error."</h5>";
    }
}
?>

