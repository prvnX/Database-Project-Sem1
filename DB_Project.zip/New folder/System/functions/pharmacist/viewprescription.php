<?php

session_start();
$id=$_SESSION['staffid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>View or edit Patient prescription</title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="viewprescription.php" method="POST">
            <h1>View and Edit Prescription of a patient </h1>
            <h5>Please Enter the Patient ID of the Patient</h5>
            <div class="input-box">
            <i class='bx bx-user'></i>  
                <input type="number" placeholder="PatientID" name="pid" required>
            </div>
            <button type="submit" class="btn" name="submit"><span></span>View Prescription</button>
            <br><br>
            <a href="../../roles/pharmacist.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
        <br><br>
        <?php
        if(isset($_POST['submit'])){
            @include 'staffconfig.php';
            $id=$_SESSION['staffid'];
            $pid=$_POST['pid'];
            header('location:viewpatientprescription.php?pid='.urlencode($pid));
            }    
            ?>
    
    </div>