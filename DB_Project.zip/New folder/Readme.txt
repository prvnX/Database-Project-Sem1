database name : pharma2


					  		Use this to login
username:patient123 pw:patient123
username:patient321 pw:patient321
username:staff123 pw:staff123

***This system exclusively relies on MySQL database credentials for user authentication.So u can add a useraccount to the
database and login with that paticular account***

Patientids:1,2,3,4,5,33

staffids :1,2,3,4,5,6,7,...

											   
roles: 1-CEO 2-Chief Pharmacist 3-Pharmacist 4-Sales Associate 5-Admin 6-Technician