<?php

session_start();
$id=$_SESSION['staffid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>View Patient Orders</title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="vieworders.php" method="POST">
            <h1>View Orders of a patient </h1>
            <h5>Please Enter the Patient ID of the Patient</h5>
            <div class="input-box">
            <i class='bx bx-user'></i>  
                <input type="number" placeholder="PatientID" name="pid" required>
            </div>
            <button type="submit" class="btn" name="submit"><span></span>View Details</button>
            <br><br>
            <a href="../../roles/salesassociate.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
        <br><br>
       <h3> <center>
        <?php
        if(isset($_POST['submit'])){
            @include 'staffconfig.php';
            $id=$_SESSION['staffid'];
            $pid=$_POST['pid'];
            $sql="SELECT pr.name,p.purchased_at,p.quantity,p.cost
            FROM purchase p
            INNER JOIN product pr ON p.product_id=pr.id
            INNER JOIN prescribe pre ON p.prescribe_id=pre.id
            INNER JOIN consult c ON pre.consult_id=c.id
            WHERE c.patient_id=$pid;";
                $result=$conn->query($sql);
              if($result->num_rows>0){
          
                echo "<table border='1px' width='100%'><tr><th>Product Name </th><th>Purchased At </th><th>Quantity</th><th>Cost</th></tr>";
                    while($row=$result->fetch_assoc()){
                     echo "<tr><td>".$row['name']."</td><td>".$row['purchased_at']."</td><td>".$row['quantity'].
                    "</td><td>".$row['cost']."</td></tr>";
                    }
        
          echo"</table>";
                }
            else{
                echo "No Results";
            } 
            $conn->close();
        }
          
    ?>
        </center></h3>
    
    </div>