<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>View profile </title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href='../../css/ceofunctions/changeprofilestyle.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
            <h1>View Profile</h1>
            <div class="data">
            <?php
            @include 'staffconfig.php';
            $id=$_SESSION['staffid'];          
            $sql="SELECT * FROM staff WHERE id=$id;";
            $result=$conn->query($sql);

            if($result->num_rows>0){
                $row=$result->fetch_assoc();
                    echo "<table><tr><td> Name :</td><td>".$row['name']."</td><td><a href='update/updatename.php'><i class='bx bxs-edit'></i></a></td></tr><tr><td>
                    Emp No:</td><td>".$row['emp_no']."</td><td><a href='update/updateempno.php'><i class='bx bxs-edit'></i></a></td></tr><tr><td>Contact NO : </td><td>".$row['contact_no']."</td><td><a href='update/updatecontact.php'><i class='bx bxs-edit'></i></a></td></tr><tr><td>
                    Address : </td><td>".$row['address']."</td><td><a href='update/updateaddress.php'><i class='bx bxs-edit'></i></a></td></tr><tr><td></table>";
            }
        else{
                echo "No Results";
            }
            $conn->close();
            ?>
            </div>
            
            <a href="../../roles/technician.php?id=<?php echo $id ?>"><br><button type="button" class="btn" name="submit">Back</button></a>
        </form>
    </div>
 
</body>
</html>