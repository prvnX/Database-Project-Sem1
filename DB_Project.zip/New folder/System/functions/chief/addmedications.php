<?php

session_start();
$id=$_SESSION['staffid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Add a new medication</title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="addmedications.php" method="POST">
            <h1>Add a new medication </h1>
            <h5>Please Fill the following Details</h5>
            <div class="input-box">
            <i class='bx bx-band-aid'></i>  
                <input type="text" placeholder="Product Name" name="productname" required>
            </div>
            
            <div class="input-box">
                <div class="select-box">
                <select name="category" >
                    <option value="" disabled selected>Select the Category</option>
                    <?php
                     @include 'staffconfig.php';
                     $sql="SELECT id,name FROM category;";
                     $result=$conn->query($sql);
                     while($row=$result->fetch_assoc()){
                        $id=$row['id'];
                        $name=$row['name'];
                        echo "<option value='$id'>".$name."</option>";
                     }
                     ?>
                </select>
                </div>
            </div>
            <div class="input-box">
                <div class="select-box">
                <select name="shelf" >
                    <option value="" disabled selected>Select the Location</option>
                    <?php
                     
                     $sql="SELECT id,location FROM shelf;";
                     $result=$conn->query($sql);
                     while($row=$result->fetch_assoc()){
                        $id=$row['id'];
                        $name=$row['location'];
                        echo "<option value='$id'>".$name."</option>";
                     }
                     ?>
                </select>
                </div>
            </div>

            

            <button type="submit" class="btn" name="submit"><span></span>Add Product</button>
            <br><br>
            <a href="../../roles/chief.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
        </div>
    </div>
<?php
if(isset($_POST['submit'])){
    $productname=$_POST['productname'];
    $category=$_POST['category'];
    $shelf=$_POST['shelf'];
    $sql="INSERT INTO product (name,category_id,shelf_id) VALUES ('$productname','$category','$shelf');";
    if($conn->query($sql)==TRUE){
        header('location:success.php');
    }
    else{
        echo "ERROR <h5>".$conn->error."</h5>";
    }
}
?>

