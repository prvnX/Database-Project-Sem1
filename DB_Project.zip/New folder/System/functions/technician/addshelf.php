<?php

session_start();
$id=$_SESSION['staffid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Add a new Shelf</title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="addshelf.php" method="POST">
            <h1>Add a new Shelf </h1>
            <h5>Please Fill the following Details</h5>
            <div class="input-box">
            <i class='bx bxs-book-content'></i> 
                <input type="number" placeholder="Shelf ID" name="shelfid" required>
            </div>
            <div class="input-box">
            <i class='bx bxs-book-content'></i>
                <input type="text" placeholder="Location" name="location" required>
            </div>
            <button type="submit" class="btn" name="submit"><span></span>Add Shelf</button>
            <br><br>
            <a href="../../roles/technician.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
        </div>
    </div>
<?php
@include 'staffconfig.php';
if(isset($_POST['submit'])){
    $shelfid=$_POST['shelfid'];
    $location=$_POST['location'];
    $sql="INSERT INTO shelf VALUES ($shelfid,'$location');";
    if($conn->query($sql)==TRUE){
        header('location:success.php');
    }
    else{
        echo "ERROR <h5>".$conn->error."</h5>";
    }
}
?>
</body>
</html>
