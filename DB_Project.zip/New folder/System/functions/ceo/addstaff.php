<?php

session_start();
$id=$_SESSION['staffid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Add a new Staff member</title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="addstaff.php" method="POST">
            <h1>Add new staff Member </h1>
            <h5>Please Fill the following Details</h5>
            <div class="input-box">
            <i class='bx bx-user'></i>  
                <input type="number" placeholder="Emp_no" name="empno" required>
            </div>
            <div class="input-box">
            <i class='bx bx-rename'></i> 
                <input type="text" placeholder="Full Name" name="name" required>
            </div>
            <div class="input-box">
            <i class='bx bxs-envelope'></i>   
                <input type="text" placeholder="Address" name="address" required>
            </div>
            <div class="input-box">
            <i class='bx bxs-phone'></i>   
                <input type="text" placeholder="Contact No" name="tpno" required>
            </div>

            <div class="input-box">
                <div class="select-box">
                <select name="role" >
                    <option value="" disabled selected>Select the Role</option>
                    <option value=2>Chief Pharmacist</option>
                    <option value=3>Pharmacist</option>
                    <option value=4>Sales Associate</option>
                    <option value=6>Technician</option>
                    <option value=5>Admin</option>
                </select>
                </div>
            </div>

            <div class="input-box">
                <div class="select-box">
                <select name="department" >
                    <option value="" disabled selected>Select the Department</option>
                    <option value=1>Inventory Management</option>
                    <option value=2>Sales</option>
                    <option value=3>Customer Service</option>
                </select>
                </div>
            </div>
            
            <button type="submit" class="btn" name="submit"><span></span>Submit</button>
            <br><br>
            <a href="../../roles/ceo.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
    
    </div>
<?php
if(isset($_POST['submit'])){
    @include 'staffconfig.php';
    $empno=$_POST['empno'];
    $name=$_POST['name'];
    $address=$_POST['address'];
    $tpno=$_POST['tpno'];
    $role=$_POST['role'];
    $dep=$_POST['department'];

    $sql="INSERT INTO staff (emp_no,name,address,emp_status,contact_no,role,department_id)
             VALUES ($empno,'$name','$address','P','$tpno',$role,$dep);";
    if($conn->query($sql)==TRUE){
        header('location:addedsuccess.php');
    }
    else{
        echo "ERROR <h5>".$conn->error."</h5>";
    }
}

