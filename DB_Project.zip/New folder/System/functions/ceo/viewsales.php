<?php

session_start();
$id=$_SESSION['staffid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>View Sales</title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="viewsales.php" method="POST">
            <h1>View Sales </h1>
            <h5>From </h5>
            <div class="input-box"> 
                <input type="date" placeholder="date" name="fromdate" required>
            </div>
            <h5>To</h5>
            <div class="input-box">
                <input type="date" placeholder="date" name="todate" required>
            </div>
            <button type="submit" class="btn" name="submit"><span></span>View Sales between selected Dates</button>
            <br><br>
            <a href="viewallsales.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="allsales">View All Sales </button></a>
            <br><br>

            <a href="../../roles/ceo.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
    
    </div>
<?php
if(isset($_POST['submit'])){
        $from=$_POST['fromdate'];
        $to=$_POST['todate'];
        header('location:viewselectedsales.php?from='.urlencode($from).'&to='.urlencode($to));
}
?>
</body>
</html>

