<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>PharmaLink stafflogin </title>
    <link rel="stylesheet" href="../css/loginstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../images/logo.png" height="25px">
        </div>
        <form action="stafflogin.php" method="POST">
            <h1>Staff Login</h1>
            <div class="input-box">
            <i class='bx bxs-user'></i>    
            <input type="text" placeholder="username" name="username" required>
            </div>
            <div class="input-box">
            <i class='bx bxs-lock'></i>
                <input type="password" placeholder="password" name="password" required>
            </div>
            <div class="input-box">
            <i class='bx bxs-user'></i>
                <input type="text" placeholder="staffID" name="staffid" required>
            </div>
            <button type="submit" class="btn" name="submit"><span></span>Login</button>
            <br>
            <a href="../index.php"><br><button type="button" class="btn" name="submit">Back</button></a>
        </form>
    </div>


<?php
if(isset($_POST['submit']))
{
$uname=$_POST['username'];
$pword=$_POST['password'];
$server="localhost";
$db="pharma2";
$id=$_POST['staffid'];
$conn=new mysqli($server,$uname,$pword,$db);
if($conn->connect_error){
    header('Location:invalidlogin.php');
    exit;
}

session_start();
//$_SESSION['db_connection']=$conn;
$_SESSION['staffpassword']=$pword;
$_SESSION['stafftuname']=$uname;
$sql="SELECT role FROM staff  WHERE id=$id";
$result=$conn->query($sql);
if($result->num_rows>0){
    $row=$result->fetch_assoc();
    $roleid=$row['role'];
    if($roleid==1){
        header('location:../roles/ceo.php?id='.urlencode($id));
    }
    elseif($roleid==2){
        header('location:../roles/chief.php?id='.urlencode($id));
    }
    elseif($roleid==3){
        header('location:../roles/pharmacist.php?id='.urlencode($id));
    }
    elseif($roleid==4){
        header('location:../roles/salesassociate.php?id='.urlencode($id));
    }
    elseif($roleid==5){
        header('location:../roles/Admin.php?id='.urlencode($id));
    }
    elseif($roleid==6){
        header('location:../roles/Technician.php?id='.urlencode($id));
    }
    //Staff Roles : 1-ceo 2-chiefphar 3-pharmacist 4-salesassociate 5-Admin 6-Technician 
}
else{
    header('Location:invalidlogin.php');
}
$conn->close();
}
?>
</body>
</html>