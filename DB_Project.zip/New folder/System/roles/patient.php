<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>PharmaLink Patient Menu </title>
    <link rel="stylesheet" href="../css/patientpagestyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    
    <section>
        <div class="box">
            <div class="img">
                <img src="../images/logo.png">
            </div>
            <h1>Welocme
                <?php
                if(!(isset($_SESSION['patientuname'])&& isset($_SESSION['patientpassword']))){
                   echo "<h1>SESSION _ERROR</h1>";
                    exit;
                }
            $user=$_SESSION['patientuname'];
            $pw=$_SESSION['patientpassword'];
            $server="localhost";
            $db="pharma2";          
            $conn=new mysqli($server,$user,$pw,$db);
            $id=$_POST['patientid'];
            $sql="SELECT name FROM patient WHERE id=$id;";
            $result=$conn->query($sql);
            if($result->num_rows>0){
                $row=$result->fetch_assoc();
                echo $row['name'];
            }
            $_SESSION['patientid']=$id;
            $conn->close();
            ?>
            </h1>
            <a href="../functions/patient/viewprofile.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/viewacount.jpg" height="50px">
                </div>
                <div class="content">
                    <h3>View Profile</h3>
                
                <p>View Your Profile and Details.</p>
            </div>
            </div>
            </a>
            <a href="../functions/patient/vieworders.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/viewdelivery.png" height="50px">
                </div>
                <div class="content">
                    <h3>View Delivery Orders</h3>
                <p>View Your orders.</p>
            </div>
            </div>
            </a>
            <a href="../functions/patient/viewreports.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/viewreports.png" height="50px">
                </div>
                <div class="content">
                    <h3>View Reports</h3>
                
                <p>View Your Diagnosis Reports.</p>
            </div>
            </div>
            </a>
            <a href="../functions/patient/viewpurchased.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/purchased.png" height="50px">
                </div>
                <div class="content">
                    <h3>View Purchased Orders</h3>
                <p>View Your purchased orders.</p>
                </div>
            </div>
            </a>
            <a href="../functions/patient/addorder.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/viewdelivery.png" height="50px">
                </div>
                <div class="content">
                    <h3>Add an Orders</h3>
                <p>Add an  order.</p>
                </div>
            </div>
            </a>
            <a href="../functions/patient/changeprofile.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/changeaccount.png" height="50px">
                </div>
                <div class="content">
                    <h3>Change your Profile</h3>
               
                <p>Change your Name and Your pesonal Details.</p>
             </div>
            </div>
            </a>
            <a href="../index.php"><br><button type="button" class="btn" name="submit"><div class="buttxt">Log out</div></button></a>
        </div>
        
    </section>
    
</body>
