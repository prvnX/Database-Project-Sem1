<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>View All Sales </title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href='../../css/ceofunctions/viewstaffstyle.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
            <h1>View All Time Sales</h1>
            <div class="data">
                <?php
            
              @include 'staffconfig.php';
              $id=$_SESSION['staffid'];
            $sql="SELECT p.id,prescribe_id,pr.name,purchased_at,quantity,cost FROM purchase p INNER JOIN product pr ON p.product_id=pr.id;";
            $result=$conn->query($sql);
            if($result->num_rows>0){
                echo "<table border='1px'><tr><th>ID</th><th>Prescribe ID</th><th>Product</th><th>Purchased Date</th><th>Quantity</th><th>Cost</th></tr>";
                while($row=$result->fetch_assoc()){
                    echo "<tr><td>".$row['id']."</td><td>".$row['prescribe_id']."</td><td>".$row['name'].
                    "</td><td>".$row['purchased_at']."</td><td>".$row['quantity']."</td><td>".$row['cost']."</td></tr>";
                }
                echo"</table>";
             }
        else{
                echo "No Results";
            }
            $conn->close();
            ?>
            </div>
            <br><br> <a href="../../roles/salesassociate.php?id=<?php echo $id; ?>"><button type="button" class="btn" name="submit">Back</button></a>
        </form>
    </div>
 
</body>
</html>