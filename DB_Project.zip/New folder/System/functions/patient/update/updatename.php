<?php

session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Update Patient_Name</title>
    <link rel="stylesheet" href="../../../css/patientfunctions/update/updatenamestyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../../images/logo.png" height="25px">
        </div>
        <form action="updatename.php" method="POST">
            <h1>Change Patient Name </h1>
            <h5>Please Enter Your New Name</h5>
            <div class="input-box">
                <i class='bx bx-rename'></i>   
                <input type="text" placeholder="Name" name="name" required>
            </div>
            <button type="submit" class="btn" name="submit"><span></span>Submit</button>
            <br>
            <a href="../changeprofile.php"><br><button type="button" class="btn" name="submit">Back</button></a>
        </form>
    </div>
<?php
if(isset($_POST['submit'])){
    @include 'patientconfig.php';
    $id=$_SESSION['patientid'];
    $name=$_POST['name'];
    $sql="UPDATE patient p SET p.name='$name' WHERE id=$id ;";
    if($conn->query($sql)==TRUE){
        header('location:success.php');
    }
    else{
        echo "ERROR <h5>".$conn->error."</h5>";
    }
}

