<?php
session_start();
$id=$_SESSION['staffid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Patient view Reports </title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href='../../css/patientfunctions/viewreportsstyle.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
            <h1>Patient Prescription</h1>
            <div class="data">
            <?php
            @include 'staffconfig.php';
            $pid=$_GET['pid'];
            $sql="SELECT name from patient WHERE id=$pid";
            $result=$conn->query($sql);
            $row=$result->fetch_assoc();
            echo "<h3> Patient Name : ".$row['name']."</h3>";

            $sql="SELECT p.id,consult_id,pr.name,prescribed_at,s.name as staffname,quantity FROM prescribe p INNER JOIN product pr ON p.product_id=pr.id
                    INNER JOIN consult c ON p.consult_id=c.id INNER JOIN staff s on p.staff_id=s.id WHERE c.patient_id=$pid;";
            $result=$conn->query($sql);
            if($result->num_rows>0){
                echo "<table border='1px'><tr><th>ID</th><th>Consult ID</th><th>Product</th><th>Date</th><th>Prescribed by</th><th>Quantity</th></tr>";
                while($row=$result->fetch_assoc()){
                    $preid=$row['id'];
                    $conid=$row['consult_id'];
                    echo "<tr><td>".$row['id']."</td><td>".$row['consult_id']."</td><td>".$row['name'].
                    "</td><td>".$row['prescribed_at']."</td><td>".$row['staffname']."</td><td>".$row['quantity']." &emsp;<a href='updateprescribe.php?conid=$conid&preid=$preid' style='color: white; text-decoration: none;'><i class='bx bx-edit-alt' ></i></a></td></tr>";
                }
                echo"</table>";
             }
        else{
                echo "No Results";
            }
            $conn->close();
            ?>
            </div>
            <br><br>
            <a href="../../roles/chief.php?id=<?php echo $id; ?>"><button type="button" class="btn" name="submit">Back</button></a>
        </form>
    </div>
 
</body>
</html>