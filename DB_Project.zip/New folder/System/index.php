<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>PharmaLink HomePage </title>
    <link rel="stylesheet" href="css/homepagestyle.css">
</head>
<body>
    <div class="banner">
    <div class="content">
        <img src="images/logo.png" height="80px" width="600px">
        <p>
           Your local source for premium pharmaceuticals and healthcare solutions.
        </p>
        <div class="login">
            
            <a href="loginpages/patientlogin.php"><button type="button"><span></span> Login as a Patient</button></a>
            <a href="loginpages/stafflogin.php"><button type="button"><span></span> Login as a Staff member</button></a>
        </div>
    </div>
</div>

    
</body></html>