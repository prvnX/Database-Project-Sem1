<?php

session_start();
$id=$_SESSION['staffid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Remove a Pharmacy</title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="removepharmacist.php" method="POST">
            <h1>Remove a Pharmacy </h1>
            <h5>Please Enter the Staff ID of the Pharmacist</h5>
            <div class="input-box">
            <i class='bx bx-user'></i>  
                <input type="number" placeholder="StaffID" name="staffid" required>
            </div>
            <button type="submit" class="btn" name="submit"><span></span>Remove</button>
            <br><br>
            <a href="../../roles/chief.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
    
    </div>
<?php
if(isset($_POST['submit'])){
    @include 'staffconfig.php';
    $staffid=$_POST['staffid'];
    $sql="DELETE FROM staff WHERE id=$staffid;";
    if($conn->query($sql)==TRUE){
        header('location:deletedsuccess.php');
    }
    else{
        echo "ERROR <h5>".$conn->error."</h5>";
    }
}
?>
</body>
</html>

