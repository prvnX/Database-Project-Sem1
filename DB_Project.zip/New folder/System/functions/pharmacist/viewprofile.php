<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Pharmacist view profile </title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href='../../css/ceofunctions/viewprofilestyle.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
            <h1> Pharmacist Profile</h1>
            <div class="data">
            <?php
            @include 'staffconfig.php';
            $id=$_SESSION['staffid'];
            $sql="SELECT id,emp_no,s.name AS emp_name,address,contact_no,r.name FROM staff s INNER JOIN role r ON s.role=r.role_id WHERE id=$id;";
            $result=$conn->query($sql);
            
            if($result->num_rows>0){
                $row=$result->fetch_assoc();
                    echo "<table><tr><td> ID :</td><td> ".$row['id']."</td></tr><tr><td> Name: </td><td>".$row['emp_name']."</td></tr><tr><td> EmpNO : </td><td>".$row['emp_no']."</td></tr><tr><td>
                    Address</td><td>".$row['address']."</td></tr><tr><td>Contact NO : </td><td>".$row['contact_no']."</td></tr><tr><td> Role : </td><td>".$row['name'].
                    "</td></tr></table>";
            }
        else{
                echo "No Results";
            }
           
            $conn->close();
            ?>
            </div>
            <form action="viewprofile.php" method="POST">
            <br><button type="submit" class="btn" name="submit">Back</button></a>
        </form>
        <?php
            if(isset($_POST['submit'])){
                header('location:../../roles/pharmacist.php?id='.urlencode($id));
            }
            ?>
    </div>
 
</body>
</html>