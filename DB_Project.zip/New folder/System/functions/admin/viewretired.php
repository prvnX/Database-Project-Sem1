<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Patient view orders </title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href='../../css/ceofunctions/viewstaffstyle.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
            <h1>View Staff</h1>
            <div class="data">
            <?php
              @include 'staffconfig.php';
              $id=$_SESSION['staffid'];
            $sql="SELECT s.
            id,emp_no,s.name AS emp_name,address,contact_no,r.name,d.name as dep_name FROM staff s INNER JOIN role r ON s.role=r.role_id 
                INNER JOIN department d ON s.department_id=d.id WHERE emp_status='F' ;";
            $result=$conn->query($sql);
            if($result->num_rows>0){
                echo "<table border='1px'><tr><th>ID</th><th>Emp_No</th><th>Employee Name</th><th>Address</th><th>Contact No</th><th>Role</th><th>Department</th></tr>";
                while($row=$result->fetch_assoc()){
                    echo "<tr><td>".$row['id']."</td><td>".$row['emp_no']."</td><td>".$row['emp_name'].
                    "</td><td>".$row['address']."</td><td>".$row['contact_no']."</td><td>".$row['name']."</td><td>".$row['dep_name']."</td></tr>";
                }
                echo"</table>";
             }
            else{
                echo "No Results";
            }
            $conn->close();
            ?>
            </div>
            <form action="viewretired.php" method="POST"><br>
            <br><br> <button type="submit" class="btn" name="submit">Back</button>
        </form>
        <?php
            if(isset($_POST['submit'])){
                header('location:../../roles/admin.php?id='.urlencode($id));
            }
        
            
            ?>
    </div>
 
</body>
</html>