<?php

session_start();
$id=$_SESSION['staffid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>View and Edit Medication</title>
    <link rel="stylesheet" href="../../css/ceofunctions/addstaffstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
        <form action="editmedications.php" method="POST">
            <h1>View and Edit Medication </h1>
            <h5>Please Enter the Medication Name</h5>
            <div class="input-box">
            <i class='bx bxs-capsule' ></i>  
                <input type="text" placeholder="Medication Name" name="mediname" required>
            </div>
            <button type="submit" class="btn" name="submit"><span></span>View</button>
            <br><br>
            <a href="../../roles/chief.php?id=<?php echo $id; ?>">
            <button type="button" class="btn" name="back">Back</button></a>
        </form>
        <br><br>
    <?php
if(isset($_POST['submit'])){
    @include 'staffconfig.php';
    $mediname=$_POST['mediname'];
    $sql="SELECT p.id,p.name,c.name as category,s.location FROM product p INNER JOIN category c ON c.id=p.category_id INNER JOIN shelf s ON p.shelf_id=s.id WHERE p.name LIKE '$mediname';";
    $result=$conn->query($sql);
    if($result->num_rows>0){
        while($row=$result->fetch_assoc()){
            $proid=$row['id'];
            echo "<h2><table width='100%'><tr><td>ID :</td><td>".$row['id']."</td><tr><td>Product Name :</td><td>".$row['name']."</td></tr><tr><td>Category : </td><td>".$row['category'].
            "</td><tr><td>Location : </td><td> ".$row['location']."</td></tr><tr></table></h2>";
        }
        echo "</table><a href='editproduct.php?productid=$proid'><button type='button' class='btn' name='edit'>Edit</button></a><br><br>
        <a href='removeproduct.php?productid=$proid'><button type='button' class='btn' name='edit'>Remove</button></a>";
     }
    else{
        echo "No Results";
    }
    
}
?>
    </div>

</body>
</html>

