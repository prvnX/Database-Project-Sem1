<?php
@include 'staffconfig.php';
$proid=$_GET['productid'];
$sql="DELETE FROM product WHERE id=$proid;";
if($conn->query($sql)==TRUE){
    header('location:deletesuccess.php');
}
else{
    echo "ERROR".$conn->error;
}