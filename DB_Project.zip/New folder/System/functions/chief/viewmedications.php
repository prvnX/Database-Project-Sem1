<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>View  Medications</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href='../../css/ceofunctions/viewstaffstyle.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
            <h1>View Medication Details</h1>
            <div class="data">
            <?php
              @include 'staffconfig.php';
              $id=$_SESSION['staffid'];

              $sql="SELECT p.id,p.name,c.name as category,s.location FROM product p INNER JOIN category c ON c.id=p.category_id INNER JOIN shelf s ON p.shelf_id=s.id;";
            $result=$conn->query($sql);
            if($result->num_rows>0){
                echo "<table border='1px'><tr><th>Product ID</th><th>Product Name <th>Category</th></th><th>Location</th></tr>";
                while($row=$result->fetch_assoc()){
                    echo "<tr><td>".$row['id']."</td><td>".$row['name']."</td><td>".$row['category'].
                    "</td><td>".$row['location']."</td></tr>";
                }
                echo"</table>";
             }
            else{
                echo "No Results";
            }
            $conn->close();
            ?>
            </div>
            <form action="viewmedications.php" method="POST"><br>
            <br><br> <button type="submit" class="btn" name="submit">Back</button>
        </form>
        <?php
            if(isset($_POST['submit'])){
                header('location:../../roles/chief.php?id='.urlencode($id));
            }
        
            
            ?>
    </div>
 
</body>
</html>