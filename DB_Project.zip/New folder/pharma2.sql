-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 14, 2023 at 07:41 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharma2`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `id` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Prescription Drugs'),
(2, 'Over-the-Counter Drugs'),
(3, 'Medical Supplies'),
(4, 'Dietary Supplements'),
(5, 'Herbal Remedies'),
(6, 'Homeopathic Medicines'),
(10, 'Skin Creams'),
(9, 'Wound Creams'),
(12, 'Wound Creams new'),
(14, 'Pain Killers');

-- --------------------------------------------------------

--
-- Table structure for table `consult`
--

DROP TABLE IF EXISTS `consult`;
CREATE TABLE IF NOT EXISTS `consult` (
  `id` int DEFAULT NULL,
  `patient_id` int DEFAULT NULL,
  `staff_id` int DEFAULT NULL,
  `blood_pressure` varchar(255) DEFAULT NULL,
  `pulse` varchar(255) DEFAULT NULL,
  `temperature` varchar(255) DEFAULT NULL,
  `consulted_at` datetime DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `consult`
--

INSERT INTO `consult` (`id`, `patient_id`, `staff_id`, `blood_pressure`, `pulse`, `temperature`, `consulted_at`) VALUES
(1, 1, 2, '95', '32', '62', '2023-11-01 18:32:00'),
(2, 2, 2, '95', '32', '62', '2023-11-11 15:27:00'),
(3, 3, 3, '118/76', '68', '98.7', '2023-03-10 08:15:00'),
(4, 4, 3, '122/78', '72', '98.8', '2023-04-05 11:00:00'),
(5, 5, 3, '125/85', '80', '98.9', '2023-05-12 16:20:00'),
(6, 6, 3, '128/88', '78', '99.0', '2023-06-25 09:45:00'),
(7, 1, 3, '115/75', '68', '98.2', '2023-07-10 09:00:00'),
(8, 2, 3, '135/88', '72', '98.4', '2023-08-15 12:30:00'),
(9, 3, 3, '122/80', '74', '98.5', '2023-09-20 15:45:00'),
(10, 4, 3, '128/85', '76', '98.7', '2023-10-25 11:15:00'),
(11, 5, 3, '118/78', '80', '98.9', '2023-11-30 14:00:00'),
(12, 6, 3, '125/82', '72', '98.6', '2023-12-05 08:45:00'),
(222, 2, 2, '95', '32', '62', '2023-11-17 13:53:00'),
(555, 2, 2, '95', '32', '62', '2023-11-14 16:55:00'),
(22, 1, 2, '95', '32', '62', '2023-11-14 16:56:00');

-- --------------------------------------------------------

--
-- Table structure for table `consult_diagnose`
--

DROP TABLE IF EXISTS `consult_diagnose`;
CREATE TABLE IF NOT EXISTS `consult_diagnose` (
  `consult_id` int DEFAULT NULL,
  `diagnose_code` int DEFAULT NULL,
  `diagnosed_at` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `consult_diagnose`
--

INSERT INTO `consult_diagnose` (`consult_id`, `diagnose_code`, `diagnosed_at`) VALUES
(1, 101, '2023-01-15 11:30:00'),
(2, 102, '2023-02-20 16:00:00'),
(3, 103, '2023-03-10 10:00:00'),
(4, 104, '2023-04-05 12:30:00'),
(5, 105, '2023-05-12 17:45:00'),
(6, 106, '2023-06-25 10:15:00'),
(7, 107, '2023-07-10 10:30:00'),
(8, 108, '2023-08-15 14:45:00'),
(9, 109, '2023-09-20 18:00:00'),
(10, 110, '2023-10-25 13:15:00'),
(11, 101, '2023-11-30 15:30:00'),
(12, 102, '2023-12-05 10:45:00');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
CREATE TABLE IF NOT EXISTS `delivery` (
  `id` int NOT NULL AUTO_INCREMENT,
  `purchase_id` int DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`id`, `purchase_id`, `delivery_date`, `address`) VALUES
(1, 1, '2023-01-17 09:30:00', '123 Main St'),
(2, 2, '2023-02-22 11:15:00', '456 Oak St'),
(3, 3, '2023-03-12 13:30:00', '789 Pine St'),
(4, 4, '2023-04-07 15:45:00', '321 Elm St'),
(5, 5, '2023-05-14 10:00:00', '555 Birch St'),
(6, 6, '2023-06-27 12:15:00', '999 Maple St'),
(7, 7, '2023-07-12 14:30:00', '222 Pine Ave'),
(8, 8, '2023-08-17 16:45:00', '333 Oak Ave'),
(9, 9, '2023-09-22 10:30:00', '444 Elm Ave'),
(10, 10, '2023-10-27 12:45:00', '555 Birch Ave'),
(11, 11, '2023-12-02 15:00:00', '123 Main St'),
(12, 12, '2023-12-07 11:15:00', '456 Oak St'),
(13, 8, '0000-00-00 00:00:00', '2023-11-16T12:29'),
(14, 5, '0000-00-00 00:00:00', '2023-11-27T21:30');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `id` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`) VALUES
(1, 'Inventory Management'),
(2, 'Sales'),
(3, 'Customer Service');

-- --------------------------------------------------------

--
-- Table structure for table `diagnose`
--

DROP TABLE IF EXISTS `diagnose`;
CREATE TABLE IF NOT EXISTS `diagnose` (
  `diagnode_code` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  KEY `diagnode_code` (`diagnode_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `diagnose`
--

INSERT INTO `diagnose` (`diagnode_code`, `name`) VALUES
(101, 'Common Cold'),
(102, 'Influenza'),
(103, 'Allergies'),
(104, 'Hypertension'),
(105, 'Diabetes'),
(106, 'Asthma'),
(107, 'Skin Infection'),
(108, 'Headache'),
(109, 'Gastroenteritis'),
(110, 'Muscle Strain');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
CREATE TABLE IF NOT EXISTS `patient` (
  `id` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_of_birth` datetime DEFAULT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `name`, `date_of_birth`, `contact_no`, `address`) VALUES
(1, 'Praveen Madushan', '2000-10-16 13:15:00', '+94-771234567', '12,Horana,Silanka'),
(2, 'James Bond', '1996-10-18 01:35:00', '987-654-3210', '12,Colombo,Silanka'),
(3, 'Alice Johnson', '1992-03-10 00:00:00', '555-123-7890', '789 Oak Avenue'),
(4, 'Bob Brown', '1980-12-05 00:00:00', '777-888-9999', '321 Pine Road'),
(5, 'Eve Wilson', '1995-06-25 00:00:00', '444-333-2222', '654 Cedar Lane'),
(33, 'Samantha Withanage', '1995-06-06 19:55:00', '+94-771234569', '12,Horana,Silanka');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy_board`
--

DROP TABLE IF EXISTS `pharmacy_board`;
CREATE TABLE IF NOT EXISTS `pharmacy_board` (
  `reg_no` int DEFAULT NULL,
  `staff_id` int DEFAULT NULL,
  `hire_date` datetime DEFAULT NULL,
  `termination_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pharmacy_board`
--

INSERT INTO `pharmacy_board` (`reg_no`, `staff_id`, `hire_date`, `termination_date`) VALUES
(1001, 3, '2021-01-01 00:00:00', '2026-01-01 00:00:00'),
(1002, 7, '2021-02-01 00:00:00', '2026-02-01 00:00:00'),
(1003, 9, '2021-03-01 00:00:00', '2026-03-01 00:00:00'),
(1004, 15, '2021-04-01 00:00:00', '2026-04-01 00:00:00'),
(1005, 14, '2021-05-01 00:00:00', '2026-05-01 00:00:00'),
(1006, 13, '2021-06-01 00:00:00', '2026-06-01 00:00:00'),
(1007, 12, '2021-07-01 00:00:00', '2026-07-01 00:00:00'),
(1008, 11, '2021-08-01 00:00:00', '2026-08-01 00:00:00'),
(20005, 2002, '2023-11-21 11:55:00', '2023-12-25 11:55:00');

-- --------------------------------------------------------

--
-- Table structure for table `prescribe`
--

DROP TABLE IF EXISTS `prescribe`;
CREATE TABLE IF NOT EXISTS `prescribe` (
  `id` int DEFAULT NULL,
  `consult_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `prescribed_at` datetime DEFAULT NULL,
  `staff_id` int DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `prescribe`
--

INSERT INTO `prescribe` (`id`, `consult_id`, `product_id`, `prescribed_at`, `staff_id`, `quantity`) VALUES
(1, 1, 4, '2023-11-24 20:53:00', 3, '2'),
(2, 2, 2, '2023-02-20 15:00:00', 3, '2 capsules'),
(3, 3, 3, '2023-03-10 09:30:00', 3, '1 pack'),
(4, 4, 4, '2023-04-05 12:15:00', 3, '1 bottle'),
(5, 5, 5, '2023-05-12 17:30:00', 3, '1 bar'),
(6, 6, 6, '2023-06-25 10:00:00', 3, '1 bottle'),
(7, 7, 7, '2023-11-15 17:10:00', 12, '5 tubes'),
(8, 8, 2, '2023-08-15 13:00:00', 3, '1 box'),
(9, 9, 3, '2023-09-20 16:15:00', 3, '3 packs'),
(10, 10, 4, '2023-10-25 11:45:00', 3, '1 bottle'),
(11, 11, 5, '2023-11-30 14:30:00', 3, '1 bottle'),
(12, 12, 6, '2023-12-05 09:15:00', 3, '2 bottles'),
(24, 12, 1, '2023-12-05 10:15:00', 3, '2 bottles'),
(23, 11, 6, '2023-11-30 15:45:00', 3, '1 box'),
(22, 10, 5, '2023-10-25 12:30:00', 3, '3 bottles'),
(21, 9, 4, '2023-09-20 17:45:00', 3, '1 bottle'),
(20, 8, 3, '2023-08-15 14:30:00', 3, '1 bottle'),
(19, 7, 2, '2023-07-10 10:45:00', 3, '2 packs'),
(18, 6, 1, '2023-06-25 11:30:00', 3, '1 box'),
(17, 5, 6, '2023-05-12 18:00:00', 3, '1 bottle'),
(16, 4, 5, '2023-04-05 13:45:00', 3, '1 pack'),
(15, 3, 4, '2023-03-10 10:30:00', 3, '2 bottles'),
(14, 2, 3, '2023-02-20 16:45:00', 3, '1 box'),
(13, 1, 7, '2023-11-16 17:00:00', 12, '1 tube'),
(22, 5, 4, '2023-11-17 16:05:00', 12, '1 Bottle'),
(26, 22, 11, '2023-11-23 17:04:00', 12, '3 Bottle'),
(66, 2, 10, '2023-11-15 16:11:00', 12, '1 Card'),
(55, 10, 10, '2023-11-14 16:57:00', 12, '1');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `shelf_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `category_id`, `shelf_id`) VALUES
(1, 'Pain Relief Tablets', 1, 1),
(2, 'Vitamin C Supplement', 5, 2),
(3, 'Band-Aids', 3, 3),
(4, 'Cough Syrup', 2, 4),
(5, 'Antibacterial Soap', 3, 5),
(6, 'Allergy Medication', 1, 6),
(7, 'Pain Relief Gel', 1, 7),
(8, 'Multivitamin Capsules', 4, 8),
(9, 'Adhesive Bandages', 3, 9),
(10, 'Cold and Flu Medicine', 2, 10),
(11, 'Hand Sanitizer', 3, 11),
(12, 'Nasal Decongestant', 1, 12),
(13, 'Amoxilin New', 3, 11),
(15, 'Pandol', 3, 5),
(16, 'Amoxilin New2', 3, 12);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

DROP TABLE IF EXISTS `purchase`;
CREATE TABLE IF NOT EXISTS `purchase` (
  `id` int DEFAULT NULL,
  `purchased_at` datetime DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `prescribe_id` int DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `cost` varchar(255) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`id`, `purchased_at`, `product_id`, `prescribe_id`, `quantity`, `cost`) VALUES
(1, '2023-01-16 09:30:00', 1, 1, '1 box', '$50.00'),
(2, '2023-02-21 11:00:00', 2, 2, '2 capsules', '$20.00'),
(3, '2023-03-11 13:45:00', 3, 3, '1 pack', '$15.00'),
(4, '2023-04-06 15:30:00', 4, 4, '1 bottle', '$30.00'),
(5, '2023-05-13 10:45:00', 5, 5, '1 bar', '$5.00'),
(6, '2023-06-26 12:15:00', 6, 6, '1 bottle', '$25.00'),
(7, '2023-07-11 14:00:00', 1, 7, '2 tubes', '$40.00'),
(8, '2023-08-16 16:30:00', 2, 8, '1 box', '$20.00'),
(9, '2023-09-21 09:45:00', 3, 9, '3 packs', '$45.00'),
(10, '2023-10-26 11:30:00', 4, 10, '1 bottle', '$35.00'),
(11, '2023-12-01 14:45:00', 5, 11, '1 bottle', '$15.00'),
(12, '2023-12-06 10:00:00', 6, 12, '2 bottles', '$50.00'),
(13, '2023-01-16 10:45:00', 2, 13, '3 tablets', '$25.00'),
(14, '2023-02-21 12:30:00', 3, 14, '1 box', '$30.00'),
(15, '2023-03-11 14:45:00', 4, 15, '2 bottles', '$40.00'),
(16, '2023-04-06 16:30:00', 5, 16, '1 pack', '$15.00'),
(17, '2023-05-13 11:45:00', 6, 17, '1 bottle', '$35.00'),
(18, '2023-06-26 13:15:00', 1, 18, '1 box', '$50.00'),
(19, '2023-07-11 15:30:00', 2, 19, '2 packs', '$30.00'),
(20, '2023-08-16 17:45:00', 3, 20, '1 bottle', '$25.00'),
(21, '2023-09-21 10:30:00', 4, 21, '1 bottle', '$20.00'),
(22, '2023-10-26 12:45:00', 5, 22, '3 bottles', '$45.00'),
(23, '2023-12-01 15:00:00', 6, 23, '1 box', '$10.00'),
(24, '2023-12-06 11:15:00', 1, 24, '2 bottles', '$40.00'),
(NULL, '2023-11-15 22:19:00', 4, 22, '1 Bottle', '50USD'),
(NULL, '2023-11-15 22:19:00', 4, 22, '1 Bottle', '54USD'),
(NULL, '2023-11-30 22:22:00', 15, 23, '2 cards', '54USD'),
(NULL, '2023-11-09 22:34:00', 7, 7, '1 Bottle', '50USD'),
(NULL, '2023-11-09 22:40:00', 5, 13, '1', '20usd');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `role_id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`role_id`, `name`) VALUES
(1, 'CEO'),
(2, 'Chief Pharmacist'),
(3, 'Pharmacist'),
(4, 'Sales Associate'),
(5, 'Admin'),
(6, 'Technician');

-- --------------------------------------------------------

--
-- Table structure for table `shelf`
--

DROP TABLE IF EXISTS `shelf`;
CREATE TABLE IF NOT EXISTS `shelf` (
  `id` int DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `shelf`
--

INSERT INTO `shelf` (`id`, `location`) VALUES
(1, 'A1'),
(2, 'B2'),
(3, 'C3'),
(4, 'D4'),
(5, 'E5'),
(6, 'F6'),
(7, 'G7'),
(8, 'H8'),
(9, 'I9'),
(10, 'J10'),
(11, 'K11'),
(12, 'L12'),
(12, ''),
(13, 'K22');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE IF NOT EXISTS `staff` (
  `id` int NOT NULL AUTO_INCREMENT,
  `emp_no` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `emp_status` enum('P','F') DEFAULT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `role` int DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2004 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `emp_no`, `name`, `address`, `emp_status`, `contact_no`, `role`, `department_id`) VALUES
(1, 9999, 'Miyura Thathsara', '12,Gamagoda,Warakagoda', 'P', '+94-771234569', 1, NULL),
(2, 1002, 'Pasindu Sandaruwan', '456 Oak St', 'F', '+94-771234569', 2, 1),
(3, 1003, 'David Pathirane', '789 Pine St', 'P', '555-123-4567', 3, 3),
(4, 1004, 'Olivia Thennakon', '321 Elm St', 'P', '777-888-9999', 4, 2),
(5, 1005, 'Daniel Fernando', '555 Birch St', 'F', '111-222-3333', 5, 1),
(6, 1006, 'Sopia Divas', '999 Maple St', 'P', '+94-771234567', 6, 1),
(7, 1007, 'Noah Brown', '222 Pine Ave', 'P', '555-777-8888', 3, 3),
(8, 1008, 'Ava Wilson', '333 Oak Ave', 'F', '999-888-7777', 4, 2),
(9, 1009, 'Liam Garcia', '444 Elm Ave', 'P', '333-222-1111', 3, 3),
(10, 1010, 'Emma Martinez', '555 Birch Ave', 'F', '111-444-5555', 5, 1),
(18, 1018, 'Rajitha Fernando', '123 Negombo Rd, Negombo', 'P', '999-444-5678', 4, 2),
(17, 1017, 'Dilani Perera', '456 Kandy Rd, Kandy', 'P', '888-333-7890', 4, 2),
(16, 1016, 'Aruna Silva', '789 Galle Rd, Colombo', 'P', '777-555-1234', 4, 2),
(15, 1015, 'Chamari Perera', '555 Badulla Rd, Badulla', 'P', '111-777-3456', 3, 3),
(14, 1014, 'Samantha Rajapaksa', '321 Jaffna Rd, Jaffna', 'P', '666-222-9012', 3, 3),
(11, 1011, 'Nimal Perera', '789 Galle Rd, Colombo', 'P', '777-555-1234', 3, 3),
(19, 1019, 'Malith Rajapaksa', '321 Jaffna Rd, Jaffna', 'P', '666-222-9012', 4, 2),
(20, 1020, 'Chandani Perera', '555 Badulla Rd, Badulla', 'P', '111-777-3456', 4, 2),
(22, 2005, 'sdf', 'sdf', 'P', '077662262', 6, 2),
(23, 11, 'df', 'fs', 'P', '+94-771234567', 6, 2),
(2003, 10001, 'Chamikara', '12,Gamagoda,Warakagoda', 'P', '+94-771234567', 4, 1),
(26, 444, 'Praveen Madushan', '12,Gamagoda,Warakagoda', 'P', '+94-771234567', 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE IF NOT EXISTS `suppliers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `reg_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `address`, `contact_no`, `reg_no`) VALUES
(1, 'ABC Suppliers', '123 Main Street, City1', '123-456-7890', 'REG001'),
(2, 'XYZ Distributors', '456 Oak Street, City2', '987-654-3210', 'REG002'),
(3, 'Quick Supplies', '789 Pine Street, City3', '555-123-4567', 'REG003'),
(4, 'City Hardware', '321 Elm Street, City4', '777-888-9999', 'REG004');

-- --------------------------------------------------------

--
-- Table structure for table `symptom`
--

DROP TABLE IF EXISTS `symptom`;
CREATE TABLE IF NOT EXISTS `symptom` (
  `id` int NOT NULL AUTO_INCREMENT,
  `consult_id` int DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `symptom`
--

INSERT INTO `symptom` (`id`, `consult_id`, `description`) VALUES
(1, 1, 'Fever and cold'),
(2, 2, 'Fever and cold'),
(3, 3, 'Normal vital signs, no specific symptoms'),
(4, 4, 'Slight fever and cough'),
(5, 5, 'Elevated heart rate and shortness of breath'),
(6, 6, 'Muscle pain and joint stiffness'),
(7, 7, 'Low blood pressure, feeling lightheaded'),
(8, 7, 'Nausea and stomach discomfort'),
(9, 8, 'Minor headache and fatigue'),
(10, 1, 'Fever and cold'),
(11, 222, 'kmln'),
(12, 555, 'kmln'),
(13, 22, 'ljbkl');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
