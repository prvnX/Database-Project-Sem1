<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Patient view purchased orders </title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href='../../css/patientfunctions/viewpurchasedstyle.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
            <h1>Purchased Orders</h1>
            <div class="data">
            <?php
               if(!(isset($_SESSION['patientuname'])&& isset($_SESSION['patientpassword']) && isset($_SESSION['patientid']))){
                   echo "<h1>SESSION _ERROR</h1>";
                    exit;
               }
            $user=$_SESSION['patientuname'];
            $pw=$_SESSION['patientpassword'];
            $server="localhost";
            $db="pharma2";
            $id=$_SESSION['patientid'];          
            $conn=new mysqli($server,$user,$pw,$db);
            $sql="SELECT pr.name,p.purchased_at,p.quantity,p.cost
                  FROM purchase p
                  INNER JOIN product pr ON p.product_id=pr.id
                  INNER JOIN prescribe pre ON p.prescribe_id=pre.id
                  INNER JOIN consult c ON pre.consult_id=c.id
                  WHERE c.patient_id=$id;";
            
            $result=$conn->query($sql);
            if($result->num_rows>0){
                $tot=0;
                echo "<table border='1px'><tr><th>Product Name </th><th>Purchased At </th><th>Quantity</th><th>Cost</th></tr>";
                while($row=$result->fetch_assoc()){
                    echo "<tr><td>".$row['name']."</td><td>".$row['purchased_at']."</td><td>".$row['quantity'].
                    "</td><td>".$row['cost']."</td></tr>";
                }
                echo"</table>";
             }
        else{
                echo "No Results";
            }
            $conn->close();
            ?>
            </div>
            <a href="../../loginpages/getpatientid"><br><button type="button" class="btn" name="submit">Back</button></a>
        </form>
    </div>
 
</body>
</html>