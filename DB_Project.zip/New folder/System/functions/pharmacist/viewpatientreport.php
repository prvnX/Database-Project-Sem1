<?php
session_start();
$id=$_SESSION['staffid'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Patient view Reports </title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href='../../css/patientfunctions/viewreportsstyle.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../../images/logo.png" height="25px">
        </div>
            <h1>Patient Reports</h1>
            <div class="data">
            <?php
            @include 'staffconfig.php';
            $pid=$_GET['pid'];
            $sql="SELECT name from patient WHERE id=$pid";
            $result=$conn->query($sql);
            $row=$result->fetch_assoc();
            echo "<h3> Patient Name : ".$row['name']."</h3>";           
            $sql="SELECT c.id,blood_pressure,pulse,temperature,sy.description,s.name,consulted_at FROM consult c
                   INNER JOIN staff s ON c.staff_id=s.id INNER JOIN symptom sy ON c.id=sy.consult_id WHERE patient_id=$pid;";
            $result=$conn->query($sql);
            if($result->num_rows>0){
                echo "<table border='1px'><tr><th>BP</th><th>Pulse</th><th>Temperature</th><th>Symptoms</th><th>Consulted by</th><th>Consulted at</th></tr>";
                while($row=$result->fetch_assoc()){
                    $conid=$row['id'];
                    echo "<tr><td>".$row['blood_pressure']."</td><td>".$row['pulse']."</td><td>".$row['temperature'].
                    "</td><td>".$row['description']."</td><td>".$row['name']."</td><td>".$row['consulted_at']." &emsp;<a href='updatepatientreport.php?conid=$conid&staffid=$id' style='color: white; text-decoration: none;'><i class='bx bx-edit-alt' ></i></a></td></tr>";
                }
                echo"</table>";
             }
        else{
                echo "No Results";
            }
            $conn->close();
            ?>
            </div>
            <br><br>
            <a href="../../roles/pharmacist.php?id=<?php echo $id; ?>"><button type="button" class="btn" name="submit">Back</button></a>
        </form>
    </div>
 
</body>
</html>