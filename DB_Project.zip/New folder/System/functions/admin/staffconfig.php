<?php
session_start();
if((isset($_SESSION['staffpassword'])) && (isset($_SESSION['stafftuname']))){
$pword=$_SESSION['staffpassword'];
$uname=$_SESSION['stafftuname'];
$server='localhost';
$db='pharma2';
$conn=new mysqli($server,$uname,$pword,$db);
if($conn->connect_error){
    echo "Connection Failed";
    exit;
}
}
?>