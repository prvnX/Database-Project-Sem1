<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>PharmaLink Pharmacist Menu </title>
    <link rel="stylesheet" href="../css/ceopagestyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    
    <section>
        <div class="box">
            <div class="img">
                <img src="../images/logo.png">
            </div>
            <h1>Welocme
                <?php
                $id=$_GET['id'];
                $_SESSION['staffid']=$id;
                if((isset($_SESSION['staffpassword'])) && (isset($_SESSION['stafftuname']))){
                    $pword=$_SESSION['staffpassword'];
                    $uname=$_SESSION['stafftuname'];
                    $server='localhost';
                    $db='pharma2';
                    $conn=new mysqli($server,$uname,$pword,$db);
                    if($conn->connect_error){
                        echo "Connection Failed";
                        exit;
                    }
                        $sql="SELECT s.name FROM staff s WHERE id=$id;";
                        $result=$conn->query($sql);
                        if($result->num_rows>0){
                             $row=$result->fetch_assoc();
                             $name=$row['name'];   
                            echo $name;
                    }
                    }
 
            ?>
            </h1>
            <a href="../functions/pharmacist/viewprofile.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/viewacount.jpg" height="50px">
                </div>
                <div class="content">
                    <h3>View Profile</h3>
                
                <p>View Your Profile and Details.</p>
            </div>
            </div>
            </a>


            <a href="../functions/pharmacist/addpatient.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/addpatient.png" height="50px">
                </div>
                <div class="content">
                    <h3>Add Patient</h3>
                <p>Add a patient.</p>
                </div>
            </div>
            </a>

            <a href="../functions/pharmacist/removepatient.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/removepatient.png" height="50px">
                </div>
                <div class="content">
                    <h3>Remove Patient</h3>
                <p>Remove a patient.</p>
                </div>
            </div>
            </a>
            

            <a href="../functions/pharmacist/viewpatientdetails.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/viewpatientdetails.png" height="50px">
                </div>
                <div class="content">
                    <h3>View Patient Details</h3>
                <p>View Details of a patient.</p>
                </div>
            </div>
            </a>

            <a href="../functions/pharmacist/addconsult.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/addconsult.png" height="50px">
                </div>
                <div class="content">
                    <h3>Add Consult</h3>
               
                <p>Add Consult of a patient.</p>
             </div>
            </div>

            </a>

            <a href="../functions/pharmacist/viewandeditreport.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/vieweditreport.png" height="50px">
                </div>
                <div class="content">
                    <h3>View/Edit Reports</h3>
               
                <p>View or edit reports of a patient.</p>
             </div>
            </div>
            
            </a>

            <a href="../functions/pharmacist/viewprescription.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/viewprescription.png" height="50px">
                </div>
                <div class="content">
                    <h3>View/Edit Prescription</h3>
                <p>View or edit Prescription of a patient.</p>
             </div>
            </div>        
            </a>

            <a href="../functions/pharmacist/addprescription.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/addprescription.png" height="50px">
                </div>
                <div class="content">
                    <h3>Add Prescription</h3>
                <p>Add Prescription of a patient.</p>
             </div>
            </div>        
            </a>

            <a href="../functions/pharmacist/viewmedications.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/viewmedi.png" height="50px">
                </div>
                <div class="content">
                    <h3>View Medication Details</h3>
                <p>View All Medication Details.</p>
             </div>
            </div>        
            </a>

            <a href="../functions/pharmacist/addmedications.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/viewdelivery.png" height="50px">
                </div>
                <div class="content">
                    <h3>Add Medication</h3>
                <p>Add a new medication.</p>
             </div>
            </div>        
            </a>
            
            <a href="../functions/pharmacist/editmedications.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/editremovemedi.png" height="50px">
                </div>
                <div class="content">
                    <h3>View/Edit/Remove Medication</h3>
                <p>View,Edit or Remove Details of a medication.</p>
             </div>
            </div>        
            </a>
            
            <a href="../functions/pharmacist/changeprofile.php">
            <div class="list">
                <div class="imgbx">
                    <img src="../images/icons/changeaccount.png" height="50px">
                </div>
                <div class="content">
                    <h3>Change your Profile</h3>
               
                <p>Change your Name and Your pesonal Details.</p>
             </div>
            </div>
            </a>

            <a href="../index.php"><br><button type="button" class="btn" name="submit"><div class="buttxt">Log out</div></button></a>
        </div>
        
    </section>
    
</body>
</html>