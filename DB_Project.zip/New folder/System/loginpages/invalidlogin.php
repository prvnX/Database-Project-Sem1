<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Invalid Login </title>
    <link rel="stylesheet" href="../css/invalidloginstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>

    <div class="content">
        <div class="img">
            <img src="../images/abort.png" height="100px">
        </div>
            <h1>Invalid Login Details</h1>
            <br>
            <a href="../index.php"><br><button type="button" class="btn" name="submit">Back to the Homepage</button></a>
    </div>
</body>





</html>
