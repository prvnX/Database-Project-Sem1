<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>PharmaLink getpatientid </title>
    <link rel="stylesheet" href="../css/getpatientidstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="content">
        <div class="img">
            <img src="../images/logo.png" height="25px">
        </div>
        <form action="../roles/patient.php" method="POST">
            <h1>Welcome <?php $user=$_SESSION['patientuname']; echo $user; ?></h1>
            <h5>Please Enter Your PatientID</h5>
            <div class="input-box">
                <i class='bx bxs-user'></i>    
                <input type="text" placeholder="PatientID" name="patientid" required>
            </div>
            <button type="submit" class="btn" name="submit"><span></span>Submit</button>
            <br>
            <a href="../index.php"><br><button type="button" class="btn" name="submit">Back to the MainMenu</button></a>
        </form>
    </div>