<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Success </title>
    <link rel="stylesheet" href="successstyle.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>

    <div class="content">
        <div class="img">
            <img src="success.png" height="100px">
        </div>
            <h1>Data Deleted Successfully</h1>
            <br>
            <a href="removepatient.php"><br><button type="button" class="btn" name="submit">Back</button></a>
    </div>
</body>
</html>
